<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developers Page</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 1em;
        }

        main {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            padding: 2em;
        }

        .developer {
            flex: 1 0 30%;
            margin: 1em;
        }

        .developer img {
            border-radius: 50%;
            max-width: 50%;
            height: auto;
        }

        footer {
            background-color: #333;
            color: #fff;
            padding: 1em;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Developers Page</h1>
    </header>
    <main>
        <div class="developer">
            <img src="libs/images/erdania2.jpg" alt="Developer 1">
            <h2><b>Developer 1</b></h2>
            <h3>Erdania Putri Binti Shahrul Azman <br>2022898372</h3>
        </div>

        <div class="developer">
            <img src="libs/images/adawiyah.jpg" alt="Developer 2">
            <h2>Developer 2</h2>
            <h3>Nur Adawiyah Binti Aziman <br> 2022897998</h3>
        </div>

        <div class="developer">
            <img src="libs/images/sharifah2.jpg" alt="Developer 3">
            <h2>Developer 3</h2>
            <h3>Sharifah Nurul Ain Binti Syed Ali <br> 2022815344</h3>
        </div>
    </main>
    <footer>
        <p>Go Back To Admin Dashboard <a href="admin.php" style="color: #fff;">HERE</a></p>
    </footer>
</body>
</html>
